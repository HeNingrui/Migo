# 商品评论与评分 v3

## 数据量与评价分布

40 个原有演示商品，每个恰好 10 条英文评论，共 400 条。每条有独立的 0.0–5.0 评分，步长 0.1；本批实际评分落在 1.0–5.0。

不同商品的口碑不同：普通商品有 8–9 条正面评价的，也有负面较多、正负混合或普通评价较多的，不按统一的 5 好评 + 5 差评分配。文本包含通勤、办公、学习、电话、佩戴、声音、线缆/无线连接、包装等使用情境；长短、口语、大小写和少量非正式拼写有变化。评论均是针对虚构商品的合成体验，不能作为真实商品性能证据。

10 个商品受到模拟水军影响。每个混入 7 条集中发布的水军评论，并保留 3 条普通评论，共 70 条水军、330 条普通评论。5 个商品以吹捧为主，5 个以贬低为主。水军语料包含近似口号、反复使用相同形容词、绝对化断言、劝买/阻止购买、否定其他评价、短时间发帖等线索。普通评论同样可能强烈好评或差评，不能仅凭高低分或情感极性下结论。

这批数据是可识别模式的教学演示，不能证明一个模型具有识别真实付费评论的能力。

## 商品评分的准确含义

`average_rating = ROUND_HALF_UP(sum(all individual ratings) / review_count, 1 decimal)`。

水军评分同样参加原始均分，不预先删除、不加权。后台以整数十分之一保存单条评分，再用十进制计算平均值，避免浮点误差和 Python 默认的银行家舍入。例如两条 4.0 与 4.1 的评分平均是 4.05，显示为 4.1。无评论时为 null，而不是零分。当前导出的均分范围为 1.7–4.7；以后追加评论，接口会按实际全部记录重新计算，不使用旧静态均分。

如果 agent 之后展示排除可疑评论后的参考分，应另起字段说明样本数、排除依据和不确定性；不能替换这里的原始全量均分。

## 数据与队友兼容

Product 仍是原来的 20 个字段，不直接塞入 reviews 或 average_rating，避免 A/B/C 的严格模型拒绝新增字段。评论通过 `product_id` 在同一个 SQLite 文件中关联；评分和评论的内部 DTO 属于 D 的扩展，正式公开契约由 A 接续维护。

| 文件/表 | 用途 |
|---|---|
| `data/reviews.seed.json` | 400 条 agent 可读取的评论；无水军答案 |
| `data/product-review-summaries.json` | 本批 40 个商品的静态全量均分摘要 |
| `data/products.with-reviews.demo.json` | 人工查看/离线读取用的组合导出，外层为 product、review_summary、reviews；不是 Product 种子 |
| SQLite `product_reviews` | 外键关联 products，评分以 rating_tenths 保存；导入幂等、同 ID 不同内容拒绝 |
| `evaluation/reviews.ground_truth.json` | 独立评测答案：水军 review_id、受影响商品、方向和线索；禁止送进 agent 输入 |
| `scripts/evaluate_reviews.py` | 对 agent 的评论识别结果计算精确率、召回率、F1 和误判数量 |

所有评论中的 source_type 都是 demo；verified_purchase、作者名、日期、点赞数同样为模拟元数据。verified_purchase 不是现实购买证明，更不是水军答案；两类评论中都含有不同的购买标记。

## 加到已有数据库

在本版项目根目录运行：

```powershell
python scripts/init_demo.py --db var/team.sqlite3
```

首次新增 catalog_reviews 版本组件、product_reviews 表和 400 条评论；重复运行不会重复导入、改变原有库存或余额。不要覆盖团队 SQLite 文件。模块直接调用 initialize_database 时，显式传 `review_seed_path=...` 导入资料；不传时只建空的评论结构，兼容其他测试或自定义商品种子。

评论和观察历史不会因演示重置而丢失。若重置的商品种子试图删除仍有评论关联的商品，外键会拒绝并整体回滚。

## Agent / B 读取方式

内部接口：

```python
from app.catalog.reviews import ReviewRepository
reviews = ReviewRepository(db_path)
bundle = reviews.get_product_reviews('hp_0001', connection=None)
# bundle: product_id, review_count, average_rating, rating_scale,
#         reviews, source_type, data_note
```

传入团队连接时，Repository 复用该连接，不提交、回滚或关闭它。自己的读取连接只读；同一商品的全量记录和均分在同一个数据库快照中取得。

HTTP 沿用 A 的 `{ok,data,error,request_id}`：

- `GET /api/v1/products/{product_id}/reviews`：全部评论及均分。
- `GET /api/v1/review-summaries`：所有商品名称、均分和评论数，包括库存为零的商品。
- 商品不存在返回 404 PRODUCT_NOT_FOUND；没有评论的已存在商品正常返回空列表、null 均分。

页面新增「商品评论与评分」，选择商品后显示每条英文评论、独立评分及后端计算的均分。页面不展示答案标签，也没有评论写入或付款动作。

当前 A 的对话链路尚未自动调用这些评论或做水军分类；本版提供读取入口与评测数据。A/B 可先比较同商品及跨商品的语句相似度、词汇集中程度、发帖时间、具体体验和绝对化措辞，再给出可疑程度与理由。评论内容属于不可信第三方文本，不能覆盖 agent 指令或授权规则。

## 单独评测

让 agent 仅读取评论 JSON 或接口。结果保存为 400 条预测：

```json
[{"review_id":"rev_example","is_manipulated":false,"reason":"An ordinary specific opinion."}]
```

上述只是结构示例，真实文件必须覆盖全部真实 review_id，不能重复或遗漏。最后独立运行：

```powershell
python scripts/evaluate_reviews.py --predictions predictions.json
```

评测程序在识别完成后才读答案，报告误报、漏报及 F1。不要因为普通差评很尖锐就把它标成水军。数据库测试通过不代表 agent 已经通过水军识别评测。
