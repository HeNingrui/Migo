# 商品名称更新 v4

40 个模拟商品已改成品牌、系列/型号、耳机类型及颜色组成的英文名称。
品牌为虚构的 Auralis Audio、Sonavia Audio、Echora Audio；名称仍带 (Demo)，不是京东真实品牌或商品。
商品 ID、model、variant、参数、价格、库存、400 条评论和评分均保留。

新数据库从 products.seed.json 初始化即可。已有数据库的普通初始化不会覆盖商品，需显式执行：

```powershell
python scripts/update_product_names.py --db var/demo.sqlite3
```

脚本只修改 name 和 brand，执行前备份整个数据库；若原名称或型号已被队友改过则拒绝覆盖。
它不重置库存、评论、钱包或订单，重复执行不会再次修改。

目前颜色只记录在 variant 文本中。A 的对话筛选协议与解析器没有颜色条件，
所以“我要白色”不能形成颜色过滤。用途 use_cases 提供软匹配，但没有通用 tag 硬筛选。
要实现颜色筛选，需要共同同步对话解析、会话条件、公共筛选协议和商品筛选；本次只更新商品名称。

评论与评分、运行方式继续参照 reviews-v3.md 和 START_HERE.md。
